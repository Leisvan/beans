self.assetsManifest = {
  "version": "9oughVKU",
  "assets": [
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-P/jWZ8+Alt9MyncWbDXtAOQunEIJoKzDDEZGNOfEBnw=",
      "url": "404.html"
    },
    {
      "hash": "sha256-fxs/c6LlmsTJE7CtcLhaHkIIkgH0DqNqUixtHA79aXw=",
      "url": "Beans.styles.css"
    },
    {
      "hash": "sha256-A8e6zZwhOqf7lDQqbbCYcAUv4wGE9aQxOo4WyYxR//0=",
      "url": "_content/Microsoft.DotNet.HotReload.WebAssembly.Browser/Microsoft.DotNet.HotReload.WebAssembly.Browser.99zm1jdh75.lib.module.js"
    },
    {
      "hash": "sha256-zyLDdtfqDu5i6H8WX59l49N2qLO6l9qf1lIcEXVd/qw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-mS9pp0LDTwIs9r+/tHPP3Yg0hais4uWBFGWENusMSKM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-NbwZyah+68eeq78xXShv86RPmfuycnx2BXeuGC26sWo=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-Bi+SeiAkC/dVev7U956eYaFaWF+58MchAyzzO/zmjlo=",
      "url": "_framework/Beans.itq549dkrz.wasm"
    },
    {
      "hash": "sha256-LekZrGUgayKTYfwHrlMNRMJsMwbeuxhQGEtOVitKOlo=",
      "url": "_framework/Beans.zo1txm90y4.pdb"
    },
    {
      "hash": "sha256-H6tIVeJf7oip4keTaTXYqpjpMKBzomzDIFGcjJIoBqg=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.5bxlh6v1r6.wasm"
    },
    {
      "hash": "sha256-l8cAlG25SQ/AsD4zN3JytaWXzvWX7kLvpFDWzMsDqnQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.9weg94lsvm.wasm"
    },
    {
      "hash": "sha256-6jkGLfjv/JDmVZ7NUepOOGlFtg/rPq9seE+QmtYvoqg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.af3npv0zkm.wasm"
    },
    {
      "hash": "sha256-EtQ7kqFmXk6mb8LQOYVaRDiG3djgwuOzwY90kg5wao0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.62i63yalbj.wasm"
    },
    {
      "hash": "sha256-Vu42E2lb1oqarpwo0di3H71yrBDhv98sameDTu6QiXk=",
      "url": "_framework/Microsoft.AspNetCore.Components.ufbvqn79qg.wasm"
    },
    {
      "hash": "sha256-pqce7PkfldaV2b12lNrqsKlaQ/YqSD8dgTivFSwbKCo=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.er49ged82l.wasm"
    },
    {
      "hash": "sha256-3gJ67eG9Tuze5feYA6UYbmLlqrEEzbioAgvEK+OE8DY=",
      "url": "_framework/Microsoft.CSharp.aars8n89vy.wasm"
    },
    {
      "hash": "sha256-dF05O/Z4gXc0YctasRjnE66x8/DlKZCmY7xo6BRbnfA=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.48hl73gjrj.wasm"
    },
    {
      "hash": "sha256-FFfgkx69G124mRs/UQfe64TrMe4Rsq6HRFfnsd4YLP4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.89aoj3wyx0.wasm"
    },
    {
      "hash": "sha256-hE7DrF7omnPgbblqN4LQEUaqXY/cpJRsCr0bDrTxcu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.c0no7gga62.wasm"
    },
    {
      "hash": "sha256-ktRekWEbJP2Mi3eX71h2M02Um02Nd8BY+FXB+YLMKwU=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.ijj6jsqoq5.wasm"
    },
    {
      "hash": "sha256-u5l3v5684DCUoMkAsUyQQllwTheqrZCCiClk3bXdTnc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.p3otb33hur.wasm"
    },
    {
      "hash": "sha256-pWNMPZESNuUKpXdz9bL+i5Mz+duM0sLx00WajjKyBE0=",
      "url": "_framework/Microsoft.Extensions.Configuration.tudu6fmogb.wasm"
    },
    {
      "hash": "sha256-lWjR2947abRgr2ujX8ED1jgCLYftZoPhsJFpgFeozaE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.50df5l6ut1.wasm"
    },
    {
      "hash": "sha256-bS78A9iabPICZ+qBJ9BtHe2V83XE4W7P5sMo/Y9PXMw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.pt8jzyf3zl.wasm"
    },
    {
      "hash": "sha256-fAobCQl6kIvt/tOZtM+voQjIC4VN8DUC1uLwGwJERw0=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.8rrgx94tis.wasm"
    },
    {
      "hash": "sha256-Ggg9V/ieJZQKYHiAF48oYaRJUtndfle+Y6EU/BKQMW4=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.un0vvhp4qn.wasm"
    },
    {
      "hash": "sha256-X0J1wEkx3n9OhzSr84SY0Tv6eUoxdTi+deWCHAV3B5U=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.nepz3dqojh.wasm"
    },
    {
      "hash": "sha256-1X9eklny64KH0uOFNDgW48TaVtX9uxoCHyOZadFbLyo=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.ronhek50iv.wasm"
    },
    {
      "hash": "sha256-1stfjzkCbM6mhbXu4Q2Vm/+lATrcXFoIl3hvsRgTSdo=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.yqq7dh6dls.wasm"
    },
    {
      "hash": "sha256-8grIRMMlBKEKAmoTlVDM1GNP0SIWIFWIJHeqfc6fel4=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.6jkolue1ka.wasm"
    },
    {
      "hash": "sha256-L2P/tLhZ6FSR1KG27vIE/jer8JBjOAPRMf7D9eFEUNs=",
      "url": "_framework/Microsoft.Extensions.Localization.xcslyy3nju.wasm"
    },
    {
      "hash": "sha256-DeXmWIdJBPz/VvbIdqIFxDs+4kARuUyVuV0C3zgn0PM=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.fx053lvd5i.wasm"
    },
    {
      "hash": "sha256-1DbhdEuz4aUXOwK0q9qEp2Fegnlehx31Ith6g9p/8uQ=",
      "url": "_framework/Microsoft.Extensions.Logging.k8ebezewz8.wasm"
    },
    {
      "hash": "sha256-OLL7tRxlzbWUH07vS9BtPgXMn20nvvKrruVCvkC4LHI=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.sj4vh1tcw0.wasm"
    },
    {
      "hash": "sha256-kurwqt1gGmdq5AiWbMLQ8+cvJErlOfJEQ3JdmHbHPPc=",
      "url": "_framework/Microsoft.Extensions.Options.y8d2bg9egb.wasm"
    },
    {
      "hash": "sha256-jdXQzOtzZU4IM3wWyQUu5MDUpBixLPoIWn4eRT/NpkE=",
      "url": "_framework/Microsoft.Extensions.Primitives.p97bsc9w07.wasm"
    },
    {
      "hash": "sha256-QL0VVc1QNb9w2TW8hgjJ7fz6xIDOYHb325mkHrrn0hY=",
      "url": "_framework/Microsoft.Extensions.Validation.s9uws8ubz2.wasm"
    },
    {
      "hash": "sha256-Es1UcLTXKcVR4L2Ul0JevLxxvsl5a9ZAfUNAlgil/qQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.2wxueyrecd.wasm"
    },
    {
      "hash": "sha256-dMTnnVj+THPGxhfXCe6UBxsfxRQsjbmgg1ZJi/JY25I=",
      "url": "_framework/Microsoft.JSInterop.gz1u6cmwu6.wasm"
    },
    {
      "hash": "sha256-8m+eoh3j2CkdhnDU7ragGuZyq3BwjyhlGG4L4y+UMfc=",
      "url": "_framework/Microsoft.VisualBasic.Core.upxd87cdr1.wasm"
    },
    {
      "hash": "sha256-m7F1G6mWYfv0m+78bmZ0ZfyvPPLwAei7lQJN64m0/1k=",
      "url": "_framework/Microsoft.VisualBasic.lo3va0ewdb.wasm"
    },
    {
      "hash": "sha256-Q04hLLvVoYHZMKaK4n4wkH2dCS9V4HFK1zmVUovdvxQ=",
      "url": "_framework/Microsoft.Win32.Primitives.xf0i7ifc2c.wasm"
    },
    {
      "hash": "sha256-8rMGn/EzYH30LD6y/xwL+4RVksITbiQjQBF1Uz/Xmg8=",
      "url": "_framework/Microsoft.Win32.Registry.egcs66c38p.wasm"
    },
    {
      "hash": "sha256-2b6bwcZ+Z0p7TKd1rR71z60JrFIaPOMWPiSm8nvH/BY=",
      "url": "_framework/MudBlazor.5dwodu6xxb.wasm"
    },
    {
      "hash": "sha256-WssdXF9UYOME7Yn9n9lb1Ul8zyLoMrBlt7C8V76uLxc=",
      "url": "_framework/System.AppContext.229uy454et.wasm"
    },
    {
      "hash": "sha256-S1bP+mwrdo06J+IiAf+zz0rtwYartsBKUjeHztg5wZQ=",
      "url": "_framework/System.Buffers.ffy4vk49sl.wasm"
    },
    {
      "hash": "sha256-hE/sGzRTqgrQuV3Bh7WiiZL6jBvGOqKmWtVCf1OZe10=",
      "url": "_framework/System.Collections.0nghqyig8i.wasm"
    },
    {
      "hash": "sha256-8btm7EOtpiXzGfhfwzmEpjtFwx02celUztylfjCr/F8=",
      "url": "_framework/System.Collections.Concurrent.vwjty21qm0.wasm"
    },
    {
      "hash": "sha256-zgrZqD7M2kJn6O4a+olV+BXL7S4rTXt+3JMCOoA3oZw=",
      "url": "_framework/System.Collections.Immutable.62ow9webvq.wasm"
    },
    {
      "hash": "sha256-JOoWnaAQS6hJn/RGGfWmWZhJBOI+GKDFXYzmmJ8TcA8=",
      "url": "_framework/System.Collections.NonGeneric.8znze2bng9.wasm"
    },
    {
      "hash": "sha256-mZddTvPLwxNBWaLhU/GQGBO//1GoMWINzlkN3H5D2I0=",
      "url": "_framework/System.Collections.Specialized.xek5hgzu5v.wasm"
    },
    {
      "hash": "sha256-HxoU00taIL24knzyMNSGgjJgr/v+58ZN9Voi4xb+BPw=",
      "url": "_framework/System.ComponentModel.1kxs5658en.wasm"
    },
    {
      "hash": "sha256-5QcjYzxFcjAmRl6DmDb0f6bH+BYGwgw4JfZPH4HUhps=",
      "url": "_framework/System.ComponentModel.Annotations.x5puxnf36m.wasm"
    },
    {
      "hash": "sha256-9CCxjyp4kY8kWIu6wCjHgnZpgIZf6UI68yvIXm6YctY=",
      "url": "_framework/System.ComponentModel.DataAnnotations.w951woxztj.wasm"
    },
    {
      "hash": "sha256-C8FNEouAC8CNin4gdVjQOdFrKEmLkx2YqtP09fY1baw=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.xxfp6nuzvv.wasm"
    },
    {
      "hash": "sha256-v2zKFujiqwTb3P2cOPrXC1HEldWEI3pwgdZNFbQaGOU=",
      "url": "_framework/System.ComponentModel.Primitives.lfp6xvb2nc.wasm"
    },
    {
      "hash": "sha256-8+Y/h8KkQLNlo4bvYZC1wzlXOPqOR8tVylHxx85xd1k=",
      "url": "_framework/System.ComponentModel.TypeConverter.b6pminnty5.wasm"
    },
    {
      "hash": "sha256-N1a6CdmRV9fO2aXVYOUySLRdAWOlFYYm3El247iEGJY=",
      "url": "_framework/System.Configuration.dfuzh9rwie.wasm"
    },
    {
      "hash": "sha256-H/Sx5NlfVSeAtZeHtr7PMuQWVneNQVpCtCp7UNMrY8w=",
      "url": "_framework/System.Console.5bpbf67g8o.wasm"
    },
    {
      "hash": "sha256-OTzFvGFn5++iP4AbzhJjX2nGZVGMtjTo6gKknK2vxrw=",
      "url": "_framework/System.Core.zxsh7ohdyg.wasm"
    },
    {
      "hash": "sha256-8VqAXbEtUOzS+tplhOSfma2VjVA4Ktaw5vsKZDLOE+w=",
      "url": "_framework/System.Data.Common.f0gomia98j.wasm"
    },
    {
      "hash": "sha256-/VKTmfp2bMHFmxYLN57I7CcU2kEdUFD4a+fUFKKT2ys=",
      "url": "_framework/System.Data.DataSetExtensions.3k3coynn1w.wasm"
    },
    {
      "hash": "sha256-z4yefYrpwUHZ9gq0MdCdTshjFcGsfybZuzyRH1ZfLUg=",
      "url": "_framework/System.Data.d1s9ppg3o7.wasm"
    },
    {
      "hash": "sha256-TjWNA5+NGYI8MZDsoirxDZiMIpG4DVpNSRVgJ6JVxyw=",
      "url": "_framework/System.Diagnostics.Contracts.yj802auekg.wasm"
    },
    {
      "hash": "sha256-SRHogrj3vV8crpFqMCG9UAeiiI+uQsrOz1RWGn+y9RI=",
      "url": "_framework/System.Diagnostics.Debug.d3luf33vju.wasm"
    },
    {
      "hash": "sha256-NArlVa0x8G+wITe/2iga0/IDYX51slTbph1l/qD3Evc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.4iwxfpqf71.wasm"
    },
    {
      "hash": "sha256-ccA+iO7gVZFXXl6zeZPGzgTgYKRCVwUUhiWRuqi9dqg=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.pqffbmgf59.wasm"
    },
    {
      "hash": "sha256-cT9fW2eUn1cE+CZ7CLBjxieFx7SZ9xQv6I2B3v3lZPI=",
      "url": "_framework/System.Diagnostics.Process.hgedtugxkh.wasm"
    },
    {
      "hash": "sha256-XriiYihH6QlM9+YB6QhQBxIZf7EpnvcsN4TSNOcCX6A=",
      "url": "_framework/System.Diagnostics.StackTrace.apl6dmc0ay.wasm"
    },
    {
      "hash": "sha256-UZSunhOgYjFKFSPSVJzF3n1Kpm3TGVnqnBZ3ZiuC1cQ=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.p621ruagc5.wasm"
    },
    {
      "hash": "sha256-baLr3RjKSvLNb/JDQ3OsjIfj8eZCGrt3t31aYQnw8Qw=",
      "url": "_framework/System.Diagnostics.Tools.f5hnfusd9n.wasm"
    },
    {
      "hash": "sha256-K4qsHlYFQnE/+tyl4vVi3tp5bPJhFCUCtAVHLBBHwKM=",
      "url": "_framework/System.Diagnostics.TraceSource.z6jsaoha6p.wasm"
    },
    {
      "hash": "sha256-T397nDWtv03LsEPL7f2EabF37N2kI7v0X53tkqEWHMw=",
      "url": "_framework/System.Diagnostics.Tracing.d1w6x6c56c.wasm"
    },
    {
      "hash": "sha256-a2vpNVIyCKOAh7IVJE9U/VEOP3A2hVF8ZpqJFqIAy4g=",
      "url": "_framework/System.Drawing.Primitives.l0kpbmmg5r.wasm"
    },
    {
      "hash": "sha256-1ruiHiGrBmbvLnir95mJVMTWTUjg/YmeVTypIkGvQsY=",
      "url": "_framework/System.Drawing.ur4stg427u.wasm"
    },
    {
      "hash": "sha256-FfnZg2GXW/4S1j6qwV70E2dmpjJDRJssZ5uT1nH2yuE=",
      "url": "_framework/System.Dynamic.Runtime.hhm1961hd1.wasm"
    },
    {
      "hash": "sha256-W9/W8n9DfFSDP49YmZip6GY6HJuT0zegpJshTpFWM6o=",
      "url": "_framework/System.Formats.Asn1.9b1kh77dim.wasm"
    },
    {
      "hash": "sha256-uaQsp+nl3nBqnL/D7Yb5z37CRybrB5d8zOWvH+LXAFc=",
      "url": "_framework/System.Formats.Tar.pwu9oiomot.wasm"
    },
    {
      "hash": "sha256-WPfj3mMulNgC/9qe/382WoDaKPWE6OfZUcRyp5FFi/s=",
      "url": "_framework/System.Globalization.Calendars.w6686c3eg8.wasm"
    },
    {
      "hash": "sha256-DFruHApFNJLjlR6F6N0DyHTX0ZKLWNc3zH/Dl6/2jeA=",
      "url": "_framework/System.Globalization.Extensions.koczvzp0tt.wasm"
    },
    {
      "hash": "sha256-1JcNqQdI1SsK9ZxFHxWDAgIZ/cxrdjeNhJSKfFa4bl4=",
      "url": "_framework/System.Globalization.k8m97q3m8s.wasm"
    },
    {
      "hash": "sha256-rm3t7FvR+GtQZ86Mg24J28HoqZr79n5WSPB4S0t1uWU=",
      "url": "_framework/System.IO.Compression.Brotli.66hvl0dk85.wasm"
    },
    {
      "hash": "sha256-mW11MEGDlAS8hNlZCkbRZqUeJZEOLBu99ycr1HoxbMo=",
      "url": "_framework/System.IO.Compression.FileSystem.jhbp0nl2b8.wasm"
    },
    {
      "hash": "sha256-MQTAsjsxBx/bC0GnAiMaeMsRXkKCgyhCWd4ugvt829c=",
      "url": "_framework/System.IO.Compression.ZipFile.nap78ewmdw.wasm"
    },
    {
      "hash": "sha256-HFxXjIIxeat1OUzx2R8xaHEm9Rg7rKjl+2Lf2elQ7Xc=",
      "url": "_framework/System.IO.Compression.wjdy7ns833.wasm"
    },
    {
      "hash": "sha256-AvX28dKMjFnPq9Egaz20NWswlioY8lYL7UMsPgVm+G0=",
      "url": "_framework/System.IO.FileSystem.AccessControl.eod3jwbqn7.wasm"
    },
    {
      "hash": "sha256-eWZLHIjiBgJhvz5gAfN6SqzZ+Z7ySIWoe7tMaut3JAM=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.driq9z3dvq.wasm"
    },
    {
      "hash": "sha256-HNwbjHhTu3l1+TIFrDGhq+XjUHLXcHJOkmJzN7hGJKg=",
      "url": "_framework/System.IO.FileSystem.Primitives.81fwc35czq.wasm"
    },
    {
      "hash": "sha256-In3DoobE9QC1SIcxRrT3ivBHgc+FbMmzlnSnHtPuC/s=",
      "url": "_framework/System.IO.FileSystem.Watcher.adgwo4kuza.wasm"
    },
    {
      "hash": "sha256-K2OU/ddMO+U131ff8dq7hZVlOjlHdgguqmysQBkZfl4=",
      "url": "_framework/System.IO.FileSystem.bwu3sqaj6h.wasm"
    },
    {
      "hash": "sha256-GyI7mEGmDuTo491hNUqStDWSaWtxuANpZszEp7fyZ6Q=",
      "url": "_framework/System.IO.IsolatedStorage.h5a2uwu0ao.wasm"
    },
    {
      "hash": "sha256-8/b6I9s5CvgNSnA/KCU5zLZS6QmJXZN31h5lvwCr3DA=",
      "url": "_framework/System.IO.MemoryMappedFiles.7rigkgafok.wasm"
    },
    {
      "hash": "sha256-bx2O6FsHx5rfLrW9YgS8l5cyqft5Rya02xYnjNlxuSE=",
      "url": "_framework/System.IO.Pipelines.pq56wwa14f.wasm"
    },
    {
      "hash": "sha256-hOa42kowRBVd7flROVvpZCf4nQdfBrxVJFuwsNmAnDk=",
      "url": "_framework/System.IO.Pipes.AccessControl.orawgey7bd.wasm"
    },
    {
      "hash": "sha256-Bq2o+zM9M88AbUPVDkiuApoJpsO/NfnnPAZ6zg3k+Xo=",
      "url": "_framework/System.IO.Pipes.qv5hx9ne5m.wasm"
    },
    {
      "hash": "sha256-30XSWulMxTVsSH4eTh3EvERI+WAW5tnD6wtO5Yu2u3c=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.zjpuh62vtt.wasm"
    },
    {
      "hash": "sha256-eGvuOoo6hoTWCkQpZ6+IgUZ44aMNRa4ZwRCBQMib6tc=",
      "url": "_framework/System.IO.kdm5se4z4i.wasm"
    },
    {
      "hash": "sha256-Mr70upwO6JBSEkFlGzsqWhsCougBDOQSUZ7Ucpdcr/c=",
      "url": "_framework/System.Linq.AsyncEnumerable.24q069vvmu.wasm"
    },
    {
      "hash": "sha256-AWZYoxP0t+ICrbBXJtVSNOYLOExsSOaRN1+xUB1jjII=",
      "url": "_framework/System.Linq.Expressions.5vac4cfeo2.wasm"
    },
    {
      "hash": "sha256-GApx1/rKMYVxFzZKhqtSzgazG1ZFrF1SOBQ5f27+bk0=",
      "url": "_framework/System.Linq.Parallel.wec9zwybs3.wasm"
    },
    {
      "hash": "sha256-Mqcst10CvxJOY5rZO16yNBM6NmwnTpHZlb9r9Tjm8B8=",
      "url": "_framework/System.Linq.Queryable.aacsqokaru.wasm"
    },
    {
      "hash": "sha256-kYmYRJKg26oh/snVKlXowSciwCDqnSA8ixdK3wnHgX8=",
      "url": "_framework/System.Linq.xsk9czcoz7.wasm"
    },
    {
      "hash": "sha256-FmbrzrgYvt8thm5f1o39K9LKKeNPn6YCkXI9ZiE5w9U=",
      "url": "_framework/System.Memory.av3iy8oqe6.wasm"
    },
    {
      "hash": "sha256-ntipoZNjDFpgIoZL2+cowUNaFBaWKt7eAw9Y/lYJyUU=",
      "url": "_framework/System.Net.2jb9y9tls4.wasm"
    },
    {
      "hash": "sha256-7UbhXREL81bSPpPCe4DxyBHUBLRuog1FZarax+8AZfY=",
      "url": "_framework/System.Net.Http.Json.f5ti54ia1a.wasm"
    },
    {
      "hash": "sha256-g/ttnbXJx7qJQDM2tjlxxPc4YS19jpfKCptdMd1jdTA=",
      "url": "_framework/System.Net.Http.xnexopyo77.wasm"
    },
    {
      "hash": "sha256-jqcIIrG0ipv/+EzVdHzANNoe23LNDX80LA7O7ITekZ0=",
      "url": "_framework/System.Net.HttpListener.qea3lr0ivv.wasm"
    },
    {
      "hash": "sha256-FA0IesoSqirr8eU4fyXNmvXSIAZyN8s7rFOBySx2n/c=",
      "url": "_framework/System.Net.Mail.kabvwy0nwb.wasm"
    },
    {
      "hash": "sha256-x+Rz/TsLnw1AaAz3rAjKA45sh8LEnqVx7A28h7/reFo=",
      "url": "_framework/System.Net.NameResolution.r77xqyi48e.wasm"
    },
    {
      "hash": "sha256-zFneucb0dssO09wgCYM+mygCgUY79ZVs5CH3FV8Zmyo=",
      "url": "_framework/System.Net.NetworkInformation.4y8ae4b47g.wasm"
    },
    {
      "hash": "sha256-C4G5LxulCxldlE480n8kD5XdC9YLJoJu82NZqorL2mY=",
      "url": "_framework/System.Net.Ping.fb39s7nqmu.wasm"
    },
    {
      "hash": "sha256-HrW4kLlKhKv1eJxLoHgBr5Sc16NXsWuQAV1YJLpLxJc=",
      "url": "_framework/System.Net.Primitives.2oo4pve6tx.wasm"
    },
    {
      "hash": "sha256-6IhW7a4wgNpdKcCgLnccMvYZnJhm8pAFwBfy0sEpZNQ=",
      "url": "_framework/System.Net.Quic.wedsu6m1ok.wasm"
    },
    {
      "hash": "sha256-HxAKTEJm/k+VeskXeJVHaLc6O6uEjiGbQP1kai1JBh0=",
      "url": "_framework/System.Net.Requests.dd8um1v0v4.wasm"
    },
    {
      "hash": "sha256-owlV6sdLRg9yetFkuF/NJeTlkcjt4x2D75W1jt4lUcM=",
      "url": "_framework/System.Net.Security.j01yc12epg.wasm"
    },
    {
      "hash": "sha256-YWvgDUfszUT659eNxpGsPSPjp4dZoZ9W1MHg5+AaKkM=",
      "url": "_framework/System.Net.ServerSentEvents.n20pwunwwa.wasm"
    },
    {
      "hash": "sha256-7sf9ZECanjhiYK5rl0nW25kL370/2X7wswsnaTCquIk=",
      "url": "_framework/System.Net.ServicePoint.6qgdmrxct2.wasm"
    },
    {
      "hash": "sha256-HLsnIASYq80lS16QqpRPfmz+MbyztpUpkhth1cEzlEA=",
      "url": "_framework/System.Net.Sockets.0jj55xk9rv.wasm"
    },
    {
      "hash": "sha256-Ayk8X4rdnD8S2NlHmRBjkdZOtU8kb9wTvL/c/oEokug=",
      "url": "_framework/System.Net.WebClient.3wc74qco9q.wasm"
    },
    {
      "hash": "sha256-hNEa+IFOoD/+JdmR0NrNVFzzAh42FRO1aWm9x5vTdAo=",
      "url": "_framework/System.Net.WebHeaderCollection.4ybcvi6krs.wasm"
    },
    {
      "hash": "sha256-SXogSzdjKcG5DG6UyQTcwM71XzKiPgLFJ1sYfndbWd0=",
      "url": "_framework/System.Net.WebProxy.zxvs9bwlaq.wasm"
    },
    {
      "hash": "sha256-BbFaIYNUlwH4460WfB489UgIcAYeLh2BEPzJ6KI5pjo=",
      "url": "_framework/System.Net.WebSockets.Client.n57nf3z1br.wasm"
    },
    {
      "hash": "sha256-gp4KiEzUX/qhvqniJZDsTc5EPRwBCRSTibR14eWoEPI=",
      "url": "_framework/System.Net.WebSockets.i3475fl55i.wasm"
    },
    {
      "hash": "sha256-N36JT9OQ2/L08Hf7azoiVDTukMEkI2cEHb1fktyBs3w=",
      "url": "_framework/System.Numerics.Vectors.tjoypuu8wa.wasm"
    },
    {
      "hash": "sha256-8VkwdV77IVGV8oP8jWcyFY+906chCyb8+j6rIrokgEo=",
      "url": "_framework/System.Numerics.zb6snwiiqo.wasm"
    },
    {
      "hash": "sha256-hq6FRf6W+TsWp4e0E86ga4sziiGnapUO5l8MUFmpmHA=",
      "url": "_framework/System.ObjectModel.qra8ipv6cl.wasm"
    },
    {
      "hash": "sha256-X0WQmwJr9mguCUK9w8xSzHiQb3Ty4p0ckSzmNJ4ykUE=",
      "url": "_framework/System.Private.CoreLib.zjh2w4p93l.wasm"
    },
    {
      "hash": "sha256-ANBBg0JT/2S2VNeD438Wf+PmlcXXKTTyBi823HZMZJw=",
      "url": "_framework/System.Private.DataContractSerialization.cdaesawoob.wasm"
    },
    {
      "hash": "sha256-iQ8wvGqvyFcs1iT1pdB2n8b/z9Mq83zK6Cods2Hwn+0=",
      "url": "_framework/System.Private.Uri.d7c7uu4en8.wasm"
    },
    {
      "hash": "sha256-9BA+zqyZhjRnJDAbbfdNxsRfrgZwyDnE4/i51LAoguY=",
      "url": "_framework/System.Private.Xml.8fl2owujec.wasm"
    },
    {
      "hash": "sha256-Pkx+wFIsSBbdhC8Ydrh+NaBr05//5uG9UcVGkGskulc=",
      "url": "_framework/System.Private.Xml.Linq.yklun9npsh.wasm"
    },
    {
      "hash": "sha256-S3eOzJcQvke43PsmexPGDIzWyieMbNkYb3jHx0UGAog=",
      "url": "_framework/System.Reflection.DispatchProxy.dur3huf884.wasm"
    },
    {
      "hash": "sha256-j/fA5WTsumDjxN2cKQTihwFLgsv3k792MiDWZ5F9ay4=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.pei97jn90w.wasm"
    },
    {
      "hash": "sha256-4gSOMD5HaI9rOga0ryYOIIw45X8cLcbKqfekiZr0nyc=",
      "url": "_framework/System.Reflection.Emit.Lightweight.ywsyqlj9p1.wasm"
    },
    {
      "hash": "sha256-9U/hGRr+m+4kX7koyKlAiMqz71022MlpL7IvKCqFUMU=",
      "url": "_framework/System.Reflection.Emit.tumhikm19o.wasm"
    },
    {
      "hash": "sha256-568p4B9FblwEE8ORe6n8IXp5ypGSazKZcK78kNFNC4w=",
      "url": "_framework/System.Reflection.Extensions.z98cfn5ig8.wasm"
    },
    {
      "hash": "sha256-TXuRF3bW1xqLJ/rQjBT0TgEq83MDIwsiB4/KasJL5Zo=",
      "url": "_framework/System.Reflection.Metadata.j4t1n1ywxj.wasm"
    },
    {
      "hash": "sha256-Wc50BQPVdMIrZQVMJDCFqEdi73OmrmdH44hZpupNu04=",
      "url": "_framework/System.Reflection.Primitives.p4ntci6hk7.wasm"
    },
    {
      "hash": "sha256-QREr11jd7UQohlfaM1KlTywvD7JasEb0zXEQV/oCLT0=",
      "url": "_framework/System.Reflection.TypeExtensions.puzzlnwex2.wasm"
    },
    {
      "hash": "sha256-J5s6vGKLVHPEEeSesDWoJfg1rK5nHKFPO8nh0+cQjaw=",
      "url": "_framework/System.Reflection.lt32pnnkzd.wasm"
    },
    {
      "hash": "sha256-5IigMfJRD+jHmWBtENiG7yAucGgOB4g3SJ6B+TnGDYA=",
      "url": "_framework/System.Resources.Reader.c8jfsntxbn.wasm"
    },
    {
      "hash": "sha256-xmSz2cgz7i1MVOIKRJZGlOstVMz6ngeaoqxl8e6HWQ0=",
      "url": "_framework/System.Resources.ResourceManager.q30psrnl7u.wasm"
    },
    {
      "hash": "sha256-XIzhaSBP9mF4R0KxLLlwzMwZowWgxNA0akSKXk1v8tw=",
      "url": "_framework/System.Resources.Writer.wvyn0j1lcg.wasm"
    },
    {
      "hash": "sha256-XjnS5kU5PJ7mLAJfWVDsm76gDJA5zRYJXtib4kVmg+s=",
      "url": "_framework/System.Runtime.6bp69qbwkj.wasm"
    },
    {
      "hash": "sha256-KZaFjGXwS8UKLDPsZ1Ry2s6vhdtPZewdY2F3Bn7ht6A=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.djrvtrz9tb.wasm"
    },
    {
      "hash": "sha256-LYtyUyzvr89kL7xicdpxXmL9woEnZ4ft6PP2FqInGt0=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.luekj4crl6.wasm"
    },
    {
      "hash": "sha256-oQ7tJvFK6fhslwTrGQEHUQ8WPKm/ukm8D6qRyPTie8o=",
      "url": "_framework/System.Runtime.Extensions.d5mymlulmr.wasm"
    },
    {
      "hash": "sha256-pk573cXMJTUukX3OqQNQCbOlmUK8MSkSUIhiYdgRKxQ=",
      "url": "_framework/System.Runtime.Handles.ih3cmfwxzd.wasm"
    },
    {
      "hash": "sha256-CIyJJNugh8zYFK3llYK2eFgYac6YUzVX+SwMw50IADU=",
      "url": "_framework/System.Runtime.InteropServices.0us88a4qml.wasm"
    },
    {
      "hash": "sha256-8+Vl/DoJkEoPx8GyRZ6Jq5VwDX4ahsWVMGPe0WJeKMk=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.flbdejno7d.wasm"
    },
    {
      "hash": "sha256-TfsdWwk+9DuqEizuk8BU4fl0Mfj40j0tMYNBM5c5/Xs=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.nvwt5l6jkw.wasm"
    },
    {
      "hash": "sha256-MR0joPBdJtCVIs7LNKWYcQnUpdvmew3tJShYuQ3QAHw=",
      "url": "_framework/System.Runtime.Intrinsics.bd7qf7pr2d.wasm"
    },
    {
      "hash": "sha256-HMLRnfB3nllRnIJLnkvHqoPEEA4Gf2MXf19MbRh2oCg=",
      "url": "_framework/System.Runtime.Loader.opo019ewpt.wasm"
    },
    {
      "hash": "sha256-JFqanWY84LrwPzl3nMjc2/10emcUXjc83c62YaczyKY=",
      "url": "_framework/System.Runtime.Numerics.opgppvbdi6.wasm"
    },
    {
      "hash": "sha256-rOajPI1BHYn4h8K+izkyPjy8YEUX0cMvrsB4W4lLPsM=",
      "url": "_framework/System.Runtime.Serialization.Formatters.seonqd55ks.wasm"
    },
    {
      "hash": "sha256-IZ703XHr5yuPJtjoVcOmSiuOwMS7oUnWFemeMuYtPjE=",
      "url": "_framework/System.Runtime.Serialization.Json.zn0mp7kdmp.wasm"
    },
    {
      "hash": "sha256-RoHClekbaVuC/3ay0FCVI5mCkDpbRZJ4ebdWu2EbC2c=",
      "url": "_framework/System.Runtime.Serialization.Primitives.yueinvlj2j.wasm"
    },
    {
      "hash": "sha256-v1Cvl1Bf9lBzICh5AIuWch8tdKQhdXbG7DqdhN8yK3A=",
      "url": "_framework/System.Runtime.Serialization.Xml.v8gymdawqg.wasm"
    },
    {
      "hash": "sha256-kLlU8Fg6mBXnrWV8AUpYvnAcfbums3BRQ/riNZvxlq0=",
      "url": "_framework/System.Runtime.Serialization.gs7sg0u955.wasm"
    },
    {
      "hash": "sha256-/vaGuzoY6wS2zhrRxCFlEtOm6Am+qnB4ZJcQH714VIc=",
      "url": "_framework/System.Security.AccessControl.6rjkcrpkiw.wasm"
    },
    {
      "hash": "sha256-ka7qPyTx8HQ3O6QpiObd/tLfTJ2KrVwAkngVxEQyfvg=",
      "url": "_framework/System.Security.Claims.hk3ae85l96.wasm"
    },
    {
      "hash": "sha256-JNEruKcOjbV3LYX7lW+6F2IByd+lUDksyL1L35Rr/3I=",
      "url": "_framework/System.Security.Cryptography.Algorithms.whyyu092ah.wasm"
    },
    {
      "hash": "sha256-0jMJ20LIrIydx5tKNMyvrlJcK1n+4vZRGjwjDTgqEC0=",
      "url": "_framework/System.Security.Cryptography.Cng.m6se2pcpu2.wasm"
    },
    {
      "hash": "sha256-i+2+zr0tjXXBsjfrzAI4mp02C7hs9cPDF5Im45pAToc=",
      "url": "_framework/System.Security.Cryptography.Csp.hhoaoktf3s.wasm"
    },
    {
      "hash": "sha256-A/64Xq6L99D6Nm+M0enQPl/m3vOgStidagno4eYvlYw=",
      "url": "_framework/System.Security.Cryptography.Encoding.52vboi33gw.wasm"
    },
    {
      "hash": "sha256-StZupImYSk5LiJhK4t5L0CbPkMm6wt5urWX4gFQKnto=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.ml0tyz68i8.wasm"
    },
    {
      "hash": "sha256-pS05GqnH2PM85VghHMYs7xyGmkHcQGD/I9d7ev0MN3w=",
      "url": "_framework/System.Security.Cryptography.Primitives.1dlu2dh7y8.wasm"
    },
    {
      "hash": "sha256-ssNeg35i32Sw3cZlBmP5bAJPkFxXGzOFdGFzkNyQF7g=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.6uh0qispd4.wasm"
    },
    {
      "hash": "sha256-juPDhNBkkR+tWofeK/InqaKq7r8hhQ4MkKORw6wGK58=",
      "url": "_framework/System.Security.Cryptography.mbts90zzn6.wasm"
    },
    {
      "hash": "sha256-xBQdFk8YXfkUf97UXhTzW0Nme0j1tGi6bfUx2XNtvzw=",
      "url": "_framework/System.Security.Principal.0lplkfn42e.wasm"
    },
    {
      "hash": "sha256-UXWNkNDLTzXH92t+pdcE67GAMNjaZobYuc1m6Syh50Q=",
      "url": "_framework/System.Security.Principal.Windows.rp57epmxji.wasm"
    },
    {
      "hash": "sha256-sTD7LfR7tR8aPciFIFfSGb2qoRyDTRdemq+HOGHUa4Q=",
      "url": "_framework/System.Security.SecureString.dhwpww24h2.wasm"
    },
    {
      "hash": "sha256-l+wMiCYTpZCWPr/O6nj+GxL1fJgtYrGvF+0O1TpsPLI=",
      "url": "_framework/System.Security.l9hsxb0sdk.wasm"
    },
    {
      "hash": "sha256-PXI//3eq/7GcJnzY7PnpSJARMqRCjzZ+pdEG5flIU7w=",
      "url": "_framework/System.ServiceModel.Web.zcvkay2idv.wasm"
    },
    {
      "hash": "sha256-u9V5OG0A7gfeD4P79wXU9r9Kmq55vLv2C7pIwFzSYcY=",
      "url": "_framework/System.ServiceProcess.x10kdcthsy.wasm"
    },
    {
      "hash": "sha256-lUReuxzuMjaHtCIWpc3dCyVOrWZYd4CEjxv32BJDpyk=",
      "url": "_framework/System.Text.Encoding.CodePages.36p8aommvy.wasm"
    },
    {
      "hash": "sha256-R+xSscSMvYx41WPDTPNk64UQpBxmEdqEc6Oo+SvkUeE=",
      "url": "_framework/System.Text.Encoding.Extensions.7s9z475qvj.wasm"
    },
    {
      "hash": "sha256-KV5UfRvlLWt5UrI4a/z74ot1UMZpDMDLCJ4LSUP/uII=",
      "url": "_framework/System.Text.Encoding.ldc2rqh80i.wasm"
    },
    {
      "hash": "sha256-nGIOG4uzsQEbo998Q7Zamu0rXC78HnvTtxpIfSw1L60=",
      "url": "_framework/System.Text.Encodings.Web.8dol48h5sw.wasm"
    },
    {
      "hash": "sha256-X3vAVtULtSZRYgEshi66iHc6dxJXHsvDo1MmJ8yFSQE=",
      "url": "_framework/System.Text.Json.3vc5r851ef.wasm"
    },
    {
      "hash": "sha256-B4WyuZja/UtHg4zhOPH85pHUiniy5+3RB1hyireaysQ=",
      "url": "_framework/System.Text.RegularExpressions.fa55zq7noc.wasm"
    },
    {
      "hash": "sha256-POSjtb073zJHnd4FDpF1624Y2w13hciDXmHxsKrM8OI=",
      "url": "_framework/System.Threading.AccessControl.0jx6t23d4a.wasm"
    },
    {
      "hash": "sha256-HTZOo3BqJ2QUqsnNWx12DkExRh1BhK8cTlxgoXJ9Ae0=",
      "url": "_framework/System.Threading.Channels.5yls0a3tlo.wasm"
    },
    {
      "hash": "sha256-bYCxenIoJmaa8lU0pUlzehe/UCqAoXnsfzXxA5MdET4=",
      "url": "_framework/System.Threading.Overlapped.7fzdvfjpcj.wasm"
    },
    {
      "hash": "sha256-314zVzc8S0pI9lhDNq4EAgTl7Y+Va4pNUZeMZmZj/o4=",
      "url": "_framework/System.Threading.Tasks.Dataflow.b1bop2hs5a.wasm"
    },
    {
      "hash": "sha256-nG3YldQlqbXqF8T29X0TfUwmXvgGldNVBPLysh6EaOU=",
      "url": "_framework/System.Threading.Tasks.Extensions.w1aib1cdwa.wasm"
    },
    {
      "hash": "sha256-5MyMawFkxrVtMdCaxt9SJWbDdaFkAs5TsdDUOJqZVnc=",
      "url": "_framework/System.Threading.Tasks.Parallel.k09pj8k6wz.wasm"
    },
    {
      "hash": "sha256-+iHad5h+QbqyxQd4dCk8LAuMoH76dUrj4xQxsv5X63o=",
      "url": "_framework/System.Threading.Tasks.ixxtp5uj8k.wasm"
    },
    {
      "hash": "sha256-YN6xDfKc00Uj33FA1RAI1dE9z2TyNB4DWvXrt7YkdAg=",
      "url": "_framework/System.Threading.Thread.oikmdgabjt.wasm"
    },
    {
      "hash": "sha256-CGiwSL1quoNt4LxugtDTwrREp+M4tJJESPlGdxdK4oU=",
      "url": "_framework/System.Threading.ThreadPool.szctd5y8bn.wasm"
    },
    {
      "hash": "sha256-XHE6vTnfUXeouXM7xp2MAr3sVNqaDj8lUsXkA3S20Gk=",
      "url": "_framework/System.Threading.Timer.k8rrsskw5o.wasm"
    },
    {
      "hash": "sha256-NNqqX2vjjeUfU00pgnRj1haCraJdawgoEARioA+wgT4=",
      "url": "_framework/System.Threading.s2hrn953g9.wasm"
    },
    {
      "hash": "sha256-1Zoj0mgGZdKxMBQnIPNzmcnbQxD4WAgI4JhpnActsgg=",
      "url": "_framework/System.Transactions.3ezo8twol7.wasm"
    },
    {
      "hash": "sha256-wZGoSjejHXWu5w/2rlsLCLyllKh2DbnV4BCM4ZJj3Zs=",
      "url": "_framework/System.Transactions.Local.nufsb5pyrr.wasm"
    },
    {
      "hash": "sha256-V/Dw40uSB6rSKAZiFOGmfAZCRWvLZLlx1oILmMJl2l0=",
      "url": "_framework/System.ValueTuple.lle7yi2fzv.wasm"
    },
    {
      "hash": "sha256-wj0yPwPNZXELkVAMQaMiUp9kO2lZVCC+VVXSQKIsUos=",
      "url": "_framework/System.Web.HttpUtility.u5rdfpwou6.wasm"
    },
    {
      "hash": "sha256-mAkfggK9Utiv1JIAbtn6IJaybrmam1gf4qqbX6fsfK8=",
      "url": "_framework/System.Web.wygikf6la5.wasm"
    },
    {
      "hash": "sha256-wgipO7KiyIOlKfYDvfGpFBiwATM63xXSVjt0ZtW7nZQ=",
      "url": "_framework/System.Windows.axtn86mzz6.wasm"
    },
    {
      "hash": "sha256-rSJv2ezwYuwgh2UtNgGITSBVA9dDNZCJA6ZhDQvp4bM=",
      "url": "_framework/System.Xml.95nan2l20b.wasm"
    },
    {
      "hash": "sha256-bYRQzNES2R69uuOmvHveYc8p0tT8LG1iN9FYebdpcdM=",
      "url": "_framework/System.Xml.Linq.j4b5ce3025.wasm"
    },
    {
      "hash": "sha256-imEzNCgsMfKb+rhr/t/ehYoI9tBe2JbvmGkOXv4b26s=",
      "url": "_framework/System.Xml.ReaderWriter.60z52rxro3.wasm"
    },
    {
      "hash": "sha256-/wJSM0ED/FHWBp7tqT1EeDEGT54CCo/ENbT+Ydk3bkY=",
      "url": "_framework/System.Xml.Serialization.pm5yw3aolk.wasm"
    },
    {
      "hash": "sha256-FfNo7biuX3HWJddNcbTEIOWrSHttQHCjgZNRkRU5Bqk=",
      "url": "_framework/System.Xml.XDocument.b4xtw4lbmx.wasm"
    },
    {
      "hash": "sha256-cU0wzV4v6Motvhc4MKUzvr1D8xbcsUkeZ4PWeNH4tL0=",
      "url": "_framework/System.Xml.XPath.XDocument.p6s7bmw3ej.wasm"
    },
    {
      "hash": "sha256-jqTPxvf1zGJ4ZjRqCIYyO3FHEkk9/RhOEscGtOTiSbQ=",
      "url": "_framework/System.Xml.XPath.egozus3d9z.wasm"
    },
    {
      "hash": "sha256-rYaPQZTnWjXchEjYFx1cVkbTD1Y2PFXaZxuGJTjxZwg=",
      "url": "_framework/System.Xml.XmlDocument.771pf23z5h.wasm"
    },
    {
      "hash": "sha256-Dy6UAhHi4CzqlUM49gXNBY2TYVEnCp3DnGLdDE3s/UM=",
      "url": "_framework/System.Xml.XmlSerializer.h0uogtkh03.wasm"
    },
    {
      "hash": "sha256-4mrPT1s4nD5ihFhuGnNShrvZRXWUX6OJlBeSs4JEHG4=",
      "url": "_framework/System.au65xu8d95.wasm"
    },
    {
      "hash": "sha256-8gsq4MhnOZbA8BrhnJy+aXHDPPZ1GRqx4vzIebgCJAg=",
      "url": "_framework/WindowsBase.mi3hkxthj8.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-q2Ib/8q6+JLLsbFaxSNz6WYlJasPLIqnoeKDSKoDw5U=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-/I3SDHIle7heAxlUGBrgxax+lkKyWyRLBVEJmTHJSCs=",
      "url": "_framework/dotnet.native.cs8mcre4gh.js"
    },
    {
      "hash": "sha256-vjddPOzSD1RO9Een4QrlAPnxzBSmD/QchBKKmBMLZwg=",
      "url": "_framework/dotnet.native.muve7a13r4.wasm"
    },
    {
      "hash": "sha256-1f0xLGKolpZn3/FELPCEicxqG0NgwMnYx0WupJ99x2g=",
      "url": "_framework/dotnet.pvuih4tmo0.js"
    },
    {
      "hash": "sha256-jCsbbdXoVd1zzGc0fQT2sz4mKuv0ANdurPVGo5Sc2jg=",
      "url": "_framework/dotnet.runtime.0j6ezsi0n0.js"
    },
    {
      "hash": "sha256-Kh2RvaoNgGY21OrfwYjP5puVIKsyvAEbaaRb2YIM9Rg=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-VqkriGENEsUw3rgDWUOjRvrIziYiKYBITxpVELFv8NI=",
      "url": "_framework/mscorlib.uifnjyorgo.wasm"
    },
    {
      "hash": "sha256-lgUuHy5ZKKRbgYfoW8t1tWMzuTpZuIcjJroQScqry7w=",
      "url": "_framework/netstandard.qvqeanc7qr.wasm"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-QO8pvlzjH7q5ibfn/KdA2r/mF8jrUkDem3nb76Yuq28=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-xCisNo3StugIabF8HnPaJOdhYQs1n44X2G6630vFHKU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-49vwoRisYW4IDOoGbtZbSThTMJNIS8POGGqJtoLQc6Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-Idp/3AVC2MAnIyJ8CzO9gC+G/u5yECxoPjc6RhG58mA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-MIzETV9rxgc8Fyw7TQ4xurkkHMz6w4L4/s+Jax585i8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-E2cG4lUD+J/iNM5IZ0fBZ8dmPaJ78vxYsHRKYrXhk38=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-i9M5YAn39r2HiBzdMb3RwRYLSUnd55JVtY9seDbQRv4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-yCRKaa0RhylYBX+vzIkTR8lLdFpI5JyssoNuJsaehXc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-iqXDyzu25CBgOcz5m+P8M9jBsTf7h90NrIRLLj3tHfM=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-9+rT7eajZL70IpUtlctNv981Yy69TlfaBpsVUaYtW/Y=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-Lc614/LP/hmqwJsrmVc0BlzTpZ/n8iD/YYbNlL18+PY=",
      "url": "manifest.webmanifest"
    }
  ]
};
